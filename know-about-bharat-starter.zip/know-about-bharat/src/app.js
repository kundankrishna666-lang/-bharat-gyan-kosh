import { seedRecords } from "./data.js";

const $ = (selector) => document.querySelector(selector);
const state = { records: [...seedRecords], query: "", source: "ALL", domain: "ALL", region: "ALL", verifiedOnly: false, hindi: true, dark: false };
const grid = $("#records-grid");
const dialog = $("#record-dialog");

function safeText(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[char]);
}
function filteredRecords() {
  const q = state.query.toLocaleLowerCase("hi");
  return state.records.filter(record => {
    const haystack = [record.titleHi, record.titleEn, record.summary, record.authority, record.sourceName, record.domain, record.region].join(" ").toLocaleLowerCase("hi");
    return (!q || haystack.includes(q)) &&
      (state.source === "ALL" || record.sourceType === state.source) &&
      (state.domain === "ALL" || record.domain === state.domain) &&
      (state.region === "ALL" || record.region === state.region || record.region === "ALL") &&
      (!state.verifiedOnly || record.verified === true);
  });
}
function render() {
  const records = filteredRecords();
  $("#result-count").textContent = records.length;
  $("#active-filters").innerHTML = [
    state.source !== "ALL" ? `स्रोत: ${safeText(state.source)}` : "सभी स्रोत",
    state.domain !== "ALL" ? safeText(state.domain) : "सभी विषय",
    state.region !== "ALL" ? safeText(state.region) : "संपूर्ण भारत",
    state.verifiedOnly ? "सत्यापित स्रोत" : ""
  ].filter(Boolean).map(item => `<span class="filter-chip">${item}</span>`).join("");
  $("#empty-state").classList.toggle("hidden", records.length !== 0);
  grid.innerHTML = records.map(record => {
    const title = state.hindi ? record.titleHi : (record.titleEn || record.titleHi);
    const badgeClass = record.sourceType === "ZENODO" ? "source-zenodo" : record.sourceType === "LOCAL" ? "source-local" : "source-gov";
    return `<article class="record-card" tabindex="0" role="button" data-id="${safeText(record.id)}" aria-label="${safeText(title)}">
      <div><div class="card-top"><span class="source-tag ${badgeClass}">${safeText(record.sourceName || record.sourceType)}</span><span class="year-tag">${safeText(record.year || "—")}</span></div>
      <h3>${safeText(title)}</h3><p>${safeText(record.summary || "विवरण उपलब्ध नहीं है।")}</p></div>
      <div class="card-bottom"><span class="${record.verified ? "verified" : "unverified"}">${record.verified ? "✓ आधिकारिक स्रोत" : "स्रोत जाँचें"}</span><span class="open-label">विवरण देखें ↗</span></div>
    </article>`;
  }).join("");
}
function showToast(message) {
  const toast = $("#toast"); toast.textContent = message; toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2600);
}
function openRecord(id) {
  const record = state.records.find(item => item.id === id); if (!record) return;
  const title = state.hindi ? record.titleHi : (record.titleEn || record.titleHi);
  $("#dialog-content").innerHTML = `<div class="dialog-content">
    <p class="eyebrow">${safeText(record.sourceName || record.sourceType)} · ${safeText(record.domain || "अन्य")}</p>
    <h2>${safeText(title)}</h2><p>${safeText(record.summary || "")}</p>
    <div class="dialog-meta"><strong>प्राधिकरण:</strong> ${safeText(record.authority || "उपलब्ध नहीं")}<br>
    <strong>क्षेत्र:</strong> ${safeText(record.region || "ALL")}<br>
    <strong>वर्ष:</strong> ${safeText(record.year || "उपलब्ध नहीं")}<br>
    <strong>स्थिति:</strong> ${record.verified ? "आधिकारिक डोमेन / डायरेक्टरी" : "स्वतंत्र रूप से सत्यापित नहीं"}</div>
    <a class="dialog-link" href="${safeText(record.url)}" target="_blank" rel="noopener noreferrer">मूल स्रोत खोलें ↗</a>
  </div>`;
  dialog.showModal();
}
async function searchZenodo() {
  const query = state.query || "India";
  const button = $("#zenodo-search"); button.disabled = true; button.textContent = "खोज जारी है…";
  $("#status-text").textContent = "Zenodo API से संपर्क हो रहा है";
  try {
    const endpoint = new URL("https://zenodo.org/api/records/");
    endpoint.searchParams.set("q", query); endpoint.searchParams.set("size", "8"); endpoint.searchParams.set("sort", "mostrecent");
    const response = await fetch(endpoint, { headers: { "Accept": "application/json" }, referrerPolicy: "no-referrer" });
    if (!response.ok) throw new Error(`Zenodo returned ${response.status}`);
    const data = await response.json();
    const hits = data?.hits?.hits || [];
    const mapped = hits.map(hit => {
      const meta = hit.metadata || {};
      const creators = (meta.creators || []).map(person => person.name).filter(Boolean).slice(0, 4).join(", ");
      const rawDescription = (meta.description || "Zenodo पर उपलब्ध ओपन-एक्सेस रिकॉर्ड।").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
      return {
        id: `zenodo-${hit.id}`, sourceType: "ZENODO", sourceName: "ZENODO · LIVE",
        domain: "Science & Space", region: "ALL", year: (meta.publication_date || "").slice(0, 4) || "—",
        titleHi: meta.title || "Zenodo Research Record", titleEn: meta.title || "",
        summary: rawDescription.slice(0, 420), url: hit.links?.html || `https://zenodo.org/records/${hit.id}`,
        authority: creators || "Zenodo record creators not listed", verified: false, doi: hit.doi || meta.doi || ""
      };
    });
    state.records = [...seedRecords, ...mapped]; render();
    $("#status-text").textContent = `${mapped.length} लाइव रिकॉर्ड प्राप्त`;
    showToast(`${mapped.length} Zenodo रिकॉर्ड मिले। प्रकाशन की गुणवत्ता अलग से जाँचें।`);
  } catch (error) {
    $("#status-text").textContent = "लाइव खोज उपलब्ध नहीं";
    showToast("Zenodo से संपर्क नहीं हो पाया। नेटवर्क या बाद में पुनः प्रयास करें।");
  } finally { button.disabled = false; button.textContent = "↗ Zenodo पर लाइव खोज"; }
}

$("#search-input").addEventListener("input", event => { state.query = event.target.value.trim(); render(); });
$("#source-filter").addEventListener("change", event => { state.source = event.target.value; render(); });
$("#domain-filter").addEventListener("change", event => { state.domain = event.target.value; render(); });
$("#region-filter").addEventListener("change", event => { state.region = event.target.value; render(); });
$("#only-verified").addEventListener("change", event => { state.verifiedOnly = event.target.checked; render(); });
$("#hindi-only").addEventListener("change", event => { state.hindi = event.target.checked; render(); });
$("#reset-filters").addEventListener("click", () => {
  Object.assign(state, { query:"", source:"ALL", domain:"ALL", region:"ALL", verifiedOnly:false, hindi:true });
  $("#search-input").value = ""; $("#source-filter").value = "ALL"; $("#domain-filter").value = "ALL"; $("#region-filter").value = "ALL";
  $("#only-verified").checked = false; $("#hindi-only").checked = true; state.records = [...seedRecords]; render();
});
$("#zenodo-search").addEventListener("click", searchZenodo);
$("#theme-toggle").addEventListener("click", () => { state.dark = !state.dark; document.documentElement.classList.toggle("dark", state.dark); });
$("#settings-toggle").addEventListener("click", event => {
  const panel = $("#settings-panel"); const isOpen = event.currentTarget.getAttribute("aria-expanded") === "true";
  event.currentTarget.setAttribute("aria-expanded", String(!isOpen)); panel.classList.toggle("hidden", isOpen && window.innerWidth <= 850);
});
grid.addEventListener("click", event => { const card = event.target.closest("[data-id]"); if (card) openRecord(card.dataset.id); });
grid.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { const card = event.target.closest("[data-id]"); if (card) { event.preventDefault(); openRecord(card.dataset.id); } } });
document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); $("#search-input").focus(); }
  if (event.key === "Escape" && dialog.open) dialog.close();
});
$("#year").textContent = new Date().getFullYear();
render();
