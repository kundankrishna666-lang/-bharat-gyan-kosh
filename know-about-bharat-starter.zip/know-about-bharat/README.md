# Know About Bharat

A responsive, dependency-light research discovery portal built with semantic HTML, modular CSS and vanilla JavaScript ES modules.

## Run locally

Because the project uses JavaScript modules, serve it over HTTP rather than opening `index.html` as a `file://` URL.

```bash
python -m http.server 8000
```

Open `http://localhost:8000`.

## GitHub Pages

1. Push this folder to a GitHub repository.
2. Open **Settings → Pages**.
3. Select **Deploy from a branch**, choose `main` and `/ (root)`.
4. Save. GitHub Pages will publish the static site.

## Project structure

```text
know-about-bharat/
├── index.html
├── README.md
└── src/
    ├── app.js
    ├── data.js
    └── styles.css
```

## Data integrity

- The initial cards are official portal directories, not fabricated statistical datasets.
- `verified: true` means the entry points to an official institutional domain; it does **not** mean every claim on that domain has been independently audited.
- Zenodo API results are marked `verified: false`. A repository record existing does not prove peer review or correctness.
- Before publishing numerical claims, store the exact dataset/document URL, publication date, update date, unit, methodology, license and a checked-by note.

## Privacy and security notes

- This is a static frontend. It does not provide a server-side firewall, anonymity guarantee, tracker blocker, or zero-trace mode.
- A Zenodo search sends the search term to Zenodo. The browser/network provider may also process ordinary connection metadata.
- External links use `noopener noreferrer`; user-provided strings are escaped before rendering.
- Do not embed arbitrary third-party pages in an iframe and call that a secure sandbox.
- For production, consider a small backend/API proxy, rate limiting, schema validation, automated link checks, content-security policy headers and an audit log.

## Extend the catalog

Add entries to `seedRecords` in `src/data.js`. Use this shape:

```js
{
  id: "unique-id",
  sourceType: "GOV", // GOV | ZENODO | LOCAL
  sourceName: "Institution / Repository",
  domain: "Governance & Policy",
  region: "Bihar", // or ALL
  year: "2026",
  titleHi: "हिंदी शीर्षक",
  titleEn: "English title",
  summary: "Short neutral summary.",
  url: "https://official-source.example/",
  authority: "Publishing institution",
  verified: false
}
```

Set `verified: true` only after checking the institutional domain. Never invent DOIs, citations, figures or peer-review status.
